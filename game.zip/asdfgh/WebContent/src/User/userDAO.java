package User;

import java.sql.*;
import java.util.*;

public class userDAO {
	public Connection DBcon() {
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/score";
			String id = "root";
			String pw = "ping9";
			
			con = DriverManager.getConnection(url, id, pw);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public ArrayList<user>userList(){
		ArrayList<user>list = new ArrayList<user>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBcon();
			String sql = "select p_uid, p_user, p_score, rank() over(order by p_score DESC)my_rank from score_table LIMIT 7";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				user dto = new user();
				dto.setP_user(rs.getString("p_user"));
				dto.setP_score(rs.getInt("p_score"));
				
				list.add(dto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) {rs.close();}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
			
			try {
				if(pstmt!=null) {pstmt.close();}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
			
			try {
				if(con!=null) {con.close();}
			}catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
}

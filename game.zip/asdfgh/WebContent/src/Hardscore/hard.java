package Hardscore;

public class hard {
	private String hd_user;
	private int hd_score;
	
	public String getHd_user() {
		return hd_user;
	}
	public void setHd_user(String hd_user) {
		this.hd_user = hd_user;
	}
	public int getHd_score() {
		return hd_score;
	}
	public void setHd_score(int hd_score) {
		this.hd_score = hd_score;
	}
}

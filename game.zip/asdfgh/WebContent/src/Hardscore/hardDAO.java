package Hardscore;

import java.sql.*;
import java.util.*;

public class hardDAO {
	public Connection DBcon() {
		Connection con = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/score";
			String id = "root";
			String pw = "ping9";
			
			con = DriverManager.getConnection(url, id, pw);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public ArrayList<hard>hardList(){
		ArrayList<hard>list = new ArrayList<hard>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBcon();
			String sql = "select hd_uid, hd_user, hd_score, rank() over(order by hd_score DESC)my_rank from score_hard LIMIT 7";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				hard dto = new hard();
				dto.setHd_user(rs.getString("hd_user"));
				dto.setHd_score(rs.getInt("hd_score"));
				
				list.add(dto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) {rs.close();}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
			
			try {
				if(pstmt!=null) {pstmt.close();}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
			
			try {
				if(con!=null) {con.close();}
			}catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
}

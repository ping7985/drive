(function(window){
	
	var laser = new Audio("assets/sound/laser.mp3");
	var diesound = new Audio("assets/sound/diesound.mp3");
	var audio = document.getElementById('audio_play');	//배경음악 시작
	if(audio.paused)
	{
		audio.play();
	}
	else{
		audio.pause();
		audio.currentTime = 0;
	}
playAudio = setInterval(function(){
	var audio = document.getElementById('audio_play');
	if(audio.paused)
	{
		audio.play();
	}
	else{
		audio.pause();
		audio.currentTime = 0;
	}
}, 168000);												//배경음악 끝
let img_backg=new Image;
let img_enemybullet = new Image;
let img_playerbullet = new Image;
let img_bossbullet = new Image;
let img_player = new Image;
let img_enemy = new Image;
let img_boss1 = new Image;
let img_boss2 = new Image;
let img_item = new Image;
let img_bomb = new Image;
let bossimg= new Image;
const plu=20;
const minu=-20;
const Boss_bul=1;
var Game = {//게임의 여러 클래스 요소 정의

	init: function(){
		this.mode=0;//플레이어의 탄환 나가는 방식정하는 변수
		this.enemymode=2;//적 탄환의 나가는 방식을 정하는 변수
		img_enemybullet.src='assets/img/enemybullet.png';
		img_playerbullet.src='assets/img/playerbullet.png';
		img_bossbullet.src='assets/img/bossbullet.png';
		img_enemy.src='assets/img/enemy.png';
		img_player.src='assets/img/player.PNG';
		img_boss1.src='assets/img/boss1.PNG';
		img_boss2.src='assets/img/boss2.png';
		img_item.src='assets/img/item.png';
		img_bomb.src='assets/img/bomb.png';
		img_backg.src='assets/img/backg2.png';
		this.c = document.getElementById("game");
		this.c.width = this.c.width;
		this.c.height = this.c.height;
		this.ctx = this.c.getContext("2d");
		this.color = "rgba(20,20,20,.7)";
		this.bullets = [];
		//this.sscore=document.getElementById("can");
		this.enemyBullets = [];
		//아이템 관련 변수들
		this.items=[]; //아이템을 모아둔 집합.
		this.itemindex=0;//아이템의 개수를 관리하는 변수
		this.itemcreate=false;//아이템이 지금 존재하는지 확인하는 변수 true면 존재함
		this.itemterm=800;  //처음 아이템이 나오는 부분
		//아이템 관련 끝
		//보스관련 변수들
		this.Bosss=[];
		this.Bossindex=0;
		this.Bosslive=false;
		this.Bosslife=0;
		this.Bossindex=0;
		this.Bossterm=900;
		//보스관련 변수끝
		this.enemies = [];
		this.particles = [];
		this.bulletIndex = 0;
		this.enemyBulletIndex = 0;
		this.enemyIndex = 0;
		this.particleIndex = 0;
		this.maxParticles = 10;
		this.maxEnemies = 10;
		this.enemiesAlive = 0;
		this.currentFrame = 0;
		this.maxLives = 20;
		this.life = 0;
		this.binding();
		this.player = new Player();
		this.score = 400;
		this.paused = false;
		this.shooting = false;
		this.oneShot = false;
		this.isGameOver = false;
		this.requestAnimationFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame;
		for(var i = 0; i<this.maxEnemies; i++){//init에서 처음 적의 수를 꽉채움
			new Enemy();
			this.enemiesAlive++;
		}
		this.invincibleMode(2000);//시작할땐 깜빡이게 설정
		//sscore.value=this.c.height;
		this.loop();//마지막으로 루프를 시작
	},

	binding: function(){// 키가 눌릴대 떼어질때 , 캔버스에서 클릭받을 때 이벤트 설정함
		window.addEventListener("keydown", this.buttonDown);//눌릴때 한번
		window.addEventListener("keyup", this.buttonUp);//키보드에서 떼어지는 순간 한번(누른뒤에 값들을 다시 초기화 시켜주는 역할임)
		window.addEventListener("keypress", this.keyPressed);//누르고 있으면 계속 실행
		this.c.addEventListener("click", this.clicked);//마우스 클릭으로 반응( 여기서 c는 html의 canvas의미)
	},//참고로 버튼이 눌리면 keypressed와 buttonDown 모두 실행된다

	clicked: function(){//캔버스에서 클릭받았을때
		if(!Game.paused) {//이미 게임중이다?
			Game.pause();//멈춘다
		} else {//
			if(Game.isGameOver){	//게임이 끝난 상태다
				Game.init();		//게임 시작
			} else {				// 그외에 상황= 멈춘상태다?
				Game.unPause();		//멈춘걸 풀고, 다시 루프를 돌린다.
				Game.loop();
				Game.invincibleMode(1000);//대신 멈췄다 다시하기때문에 플레이어는 깜빡거리게
			}
		}
	},

	keyPressed: function(e){
		if(e.keyCode === 32){//누른 키가 스페이스 일때
			if(!Game.player.invincible  && !Game.oneShot){//플레이어가 깜빡거리지 않고,
				Game.player.shoot();
				Game.oneShot = true;
				laser.currentTime = 0;
				laser.play();
			}
			if(Game.isGameOver){// 게임 오버된 상황에서 스페이스가 눌리면
				Game.init();    //buttondown에서 쓸수도 있었지만 여기다 space관련 기능을 다 몰아줌
			}
     		e.preventDefault();
		}
	},

	buttonUp: function(e){// 키를 누르고 떼어졌을때 실행되는 이벤트 => 대부분의 실행되던걸 멈추는 역할임
		if(e.keyCode === 32){//스페이스에서 손을 땠을때
			Game.shooting = false;
			Game.oneShot = false;//샷에 관한 값들을 false로 바꾸고 shooting은 쏠수 있는지 정하는값, oneshot은 space를 계속 누르고 있을때 한번만 쏘게 설정

			laser.currentTime = 0;
			laser.play();
			e.preventDefault();//이 함수는 이벤트를 취소하는기능, 즉 쏘는것을 멈춤
		}
		if(e.keyCode === 37 || e.keyCode === 65){//화살표 왼쪽키나 A에서 손이 떼어질때
			Game.player.movingLeft = false;// 왼쪽으로 가는 변수를 false로
		}
		if(e.keyCode === 39 || e.keyCode === 68){//화살표 오른쪽키나 D에서 손이 떼어질때
			Game.player.movingRight = false;//오른쪽으로 가는 변수를 false로
		}
		if(e.keyCode === 38 || e.keyCode === 87){//up
			Game.player.movingUp = false;
		}
		if(e.keyCode === 40 || e.keyCode === 83){//down
			Game.player.movingDown = false;
		}
	},

	buttonDown: function(e){//키보드를 눌렀을때 실행됨
		if(e.keyCode === 32){//32=space 를 눌렀을때
			Game.shooting = true; //사격 가능하게
			laser.currentTime = 0;
			laser.play();
		}
		if(e.keyCode === 37 || e.keyCode === 65){// 왼쪽 키를 눌렀을때
			Game.player.movingLeft = true; //움직이는거 가능하게 (이 변수값이 true인동안은 계속 움직임 즉 keypress를 쓸필요가 없음)
		}
		if(e.keyCode === 39 || e.keyCode === 68){
			Game.player.movingRight = true;
		}
		if(e.keyCode === 38 || e.keyCode === 87){//up
			Game.player.movingUp = true;
		}
		if(e.keyCode === 40 || e.keyCode === 83){//down
			Game.player.movingDown = true;
		}
	},

	random: function(min, max){/// min 과 max 사이의 랜덤값 구하는 함수
    return Math.floor(Math.random() * (max - min) + min);
    },

  invincibleMode: function(s){// 0.00s초 뒤까지만 invincible값을 참으로 만들게 하는 함수
  	this.player.invincible = true;
  	setTimeout(function(){
  		Game.player.invincible = false;
  	}, s/2);//s초 뒤에는 invincible을 false 즉 깜박이를 끄겠다.
  },

  collision: function(a, b){//충돌 판정 결정하는 함수 a에는 보통 플레이어나 적의 탄환을 의미하고, b는 플레이어나 적 스스로를 넣는다

	  return (
		  ((a.y + a.height) >= (b.y)) &&				//탄환의 윗선이 b의 아랫선과 위치가 같거나 크면서
		  (a.y <= (b.y + b.height)) &&					//탄환의 밑선이  b의 윗선과 위치가 같거나 작으면서
		  ((a.x + a.width) >= b.x) &&					//탄환의 오른쪽 선이 b의 왼쪽 선과 같거나 더 오른쪽에 있으면서
		  (a.x <= (b.x + b.width))						//탄환의 왼쪽선이 b의 오른쪽선과 같거나 더 왼쪽에 있으면
	  )//즉 탄환의 범위중 아주 조금이라도 b의 공간안에 들어오는 순간 true가 리턴된다.



/*
		return !(
	    ((a.y + a.height) < (b.y)) ||				//탄환의 윗 부분이 b의 아랫부분과 위치가 같거나 넘어간 경우,
	    (a.y > (b.y + b.height)) ||					//탄환의 밑부분이  b의 윗부분과 같거나 더 작은 경우
	    ((a.x + a.width) < b.x) ||
	    (a.x > (b.x + b.width))
		)*/
	},

  clear: function(){//캔버스를 다지우는 함수
  	//this.ctx.fillStyle = Game.color;
  	//this.ctx.fillRect(0, 0, this.c.width, this.c.height);
	  this.ctx.drawImage(img_backg, 0, 0);
	  
  },
   
  pause: function(){ //pause 변수를 true로 바꾼다
		this.paused = true;
  },

  unPause: function(){//pause변수를 false로
		this.paused = false;
  },


  gameOver: function(){ //게임오버됐을때 작동하는데,
  	this.isGameOver = true;
  	this.clear();//이미멈춘 화면위에 배경색을 한번그리고, text의 배경을 미리 그려준다
  	var message = "Game Over";
  	var message2 = "Score: " + Game.score;
  	var message3 = "Click or press Spacebar to Play Again";
  	this.pause();
  	this.ctx.fillStyle = "white";//이제 위의 메세지를 canvas에 출력함
	  this.ctx.font = "bold 30px Lato, sans-serif";
	  this.ctx.fillText(message, this.c.width/2 - this.ctx.measureText(message).width/2, this.c.height/2 - 50);
	  this.ctx.fillText(message2, this.c.width/2 - this.ctx.measureText(message2).width/2, this.c.height/2 - 5);
	  this.ctx.font = "bold 16px Lato, sans-serif";
	  this.ctx.fillText(message3, this.c.width/2 - this.ctx.measureText(message3).width/2, this.c.height/2 + 30);
  },

  updateScore: function(){//왼쪽위의 점수와 목숨을 업데이트함
  	this.ctx.fillStyle = "white";
  	this.ctx.font = "16px Lato, sans-serif";
  	this.ctx.fillText("Score: " + this.score, 8, 20);
  	this.ctx.fillText("Lives: " + (this.maxLives - this.life), 8, 40);
  },

	loop: function(){// 실행 순서: 화면 초기화-> 적개체 순서대로 업데이트 -> 적탄환 순서대로 업데이트-> 내탄환 업데이트 -> 플레이어 그리고-> 파티클(적 죽는모션) 그리고 -> 마지막 플레이어 그리는 순
		if(!Game.paused){//정지된게 아니라면 밑을 실행
			Game.clear();
			for(var i in Game.enemies){ //적 업데이트
				var currentEnemy = Game.enemies[i];
				currentEnemy.draw();
				currentEnemy.update();
				if(Game.currentFrame % currentEnemy.shootingSpeed === 0){//일정 주기마다 적 탄환 발사
					currentEnemy.shoot();//적탄환 생성 함수
				}
			}
			for(var c in Game.Bosss){ //보스 업데이트
				var currentBoss = Game.Bosss[c];
				currentBoss.draw();
				currentBoss.update();
				if(Game.currentFrame % currentBoss.shootingSpeed === 0){//일정 주기마다 적 탄환 발사
					currentBoss.shoot();//적탄환 생성 함수
				}
			}
			if(Game.itemcreate==true){//아이템 이 지금 있다면 아이템을 그리고 업데이트
				Game.items[Game.itemindex-1].draw();
				Game.items[Game.itemindex-1].update();
			}
			for(var x in Game.enemyBullets){//적 탄환 위치 그리기, 위치정보 초기화
				Game.enemyBullets[x].draw();//현재 있는 모든 적 탄환 그리고
				Game.enemyBullets[x].update();//적 탄환 정보 업데이트
			}
			for(var z in Game.bullets){//탄환? 플레이어 탄환 그리기 및 위치 업데이트
				Game.bullets[z].draw();
				Game.bullets[z].update();
			}
			if(Game.player.invincible){//플레이어가 맞았다면 깜빡거리는 설정
				if(Game.currentFrame % 20 === 0){//일정 주기가 되지 않으면 그리지 않음 으로써 깜빡이게 보임
					Game.player.draw();
				}
			} else {//맞지 않았다면 평범하게 그리고
				Game.player.draw();
			}
			if(Game.score>Game.itemterm&&Game.itemcreate==false){//아이템이 아직 없고, 일정점수를 넘었으면
				new Item();//아이템 새로만들고
				Game.itemcreate=true;//아이템 ok
				Game.itemterm+=800;//다음 아이템 나오는 점수를 지정
			}
			if(Game.score>Game.Bossterm&&Game.Bosslive==false){//보스 생성부분
				new Boss();
				Game.Bosslife=0;//보스 체력 초기화
				Game.Bosslive=true;
				Game.Bossterm+=900;
			}


	    for(var i in Game.particles){// 파티클?
	      Game.particles[i].draw();
	    }

			Game.player.update();//이때 죽으면 여기서 gameover가 발생
			Game.updateScore();//점수 업데이트 할때 킬한 만큼 스코어가 올라감. 진행시간은 영향 x
			Game.currentFrame = Game.requestAnimationFrame.call(window, Game.loop);// 이 frame값이 주기 같은거 정하게하는 변수임
		}//paused가 1이면 업데이트 아무것도 안한다. 즉 멈춰있는 것처럼 보이게 그대로 둔다
	}

};

//보스 생성 부분
	var Boss = function(){//적이 생성됐을때 사용하는 함수 대부분은 플레이어와 비슷하다
		this.width = 120;
		this.height = 165;

		 this.x = Game.c.width/2;
	      this.y = 20;//
	      var i=Game.random(0,2);
	      if(i!==0){
	         bossimg=img_boss1;
	      }
	      else if(i==0){
	         bossimg=img_boss2;
	      }
	      this.index = Game.Bossindex;         //적 배열의 인덱스 설정
	      Game.Bosss[Game.Bossindex] = this;   //배열에 배정
	      Game.Bossindex++;                  //다음을 위해 enemy값 설정
	      this.speed = 1;//Game.random(2, 3);  //옆으로 움직이는 속도 값
	      this.shootingSpeed =  Game.random(30, 80);   //발사하는 주기를 정하는 값
	      this.movingLeft = Math.random() < 0.5 ? true : false;//      처음에 반반확률로 왼쪽으로 갈지 오른쪽으로갈지 정한다.
	      this.color = "hsl("+ Game.random(0, 360) +", 60%, 50%)";//랜덤값으로 컬러를 설정

	};

	Boss.prototype.draw = function(){
		Game.ctx.drawImage(bossimg, this.x, this.y);
		//Game.ctx.fillStyle = this.color;//var Enemy fucntion에서 설정한 값으로 스타일에 저장하고
	//	Game.ctx.fillRect(this.x, this.y, this.width, this.height);//그걸로 네모 그림
	};

	Boss.prototype.update = function(){
		if(this.movingLeft){//왼쪽으로 이동하는 경우 --> movingleft값이 true일때
			if(this.x > 0){//네모의 왼쪽 선이 캔버스의 왼쪽 끝과 닿았는지 확인하고
				this.x -= this.speed;//왼쪽으로 speed값만큼 이동
				//this.y += this.vy;//왼쪽으로 갈땐 살짝 아래로 내려가며 이동
			} else {//왼쪽 끝인 경우에 한틱 멈추고
				this.movingLeft = false;//값을 바꿈
			}
		} else {//오른쪽으로 이동하는 경우 -->false
			if(this.x + this.width < Game.c.width){//네모의 오른쪽선이 캔버스의 오른쪽 끝과 닿았는지 확인
				this.x += this.speed;
				//this.y += this.vy;
			} else {//반대로 끝에 닿았다면 한틱쉬고 movingleft값을 true로
				this.movingLeft = true;
			}
		}

		for(var i in Game.bullets){//이동한후에 모든 플레이어의 탄환마다 맞았는지 검사를 실행한다.
			var currentBullet = Game.bullets[i];//예비변수 currentBullet에 탄환중 하나를 배정하고
			if(Game.collision(currentBullet, this)){//충돌검사하는 함수 collision을 실행
				this.die();
				delete Game.bullets[i];
			}
		}
	};


	Boss.prototype.die = function(){


		if(Game.Bosslife < Game.maxLives){//피가 남아 있다면

			Game.Bosslife++;//죽음에 가까워짐
		} else {//피가 없다면
			this.explode();
			delete Game.Bosss[this.index];
			Game.score += 200;
			Game.Bosslive=false;
		}


		// Game.sscore.value=this.c.height;
		/*
		Game.enemiesAlive = Game.enemiesAlive > 1 ? Game.enemiesAlive - 1 : 0;
		if(Game.enemiesAlive < Game.maxEnemies){
			Game.enemiesAlive++;
			setTimeout(function(){//적은 죽고난후 2초뒤에 새로생긴다
				new Enemy();
			}, 1000);
		}*/

	};


	Boss.prototype.explode = function(){//죽었을때 터지는 효과 함수
		for(var i=0; i<Game.maxParticles; i++){//한명이 죽을때 맥스파티클만큼의 작은 알갱이를 발생시킨다
			new Particle(this.x + this.width/2, this.y, this.color);//적의 위치와 함께 적의 색을 보내서 파티클(터지는효과)실행
		}
	};

	Boss.prototype.shoot = function(){//적이 탄환을 쏠때, 적의탄환생성함수
		new EnemyBullet(this.x + this.width/2, this.y, this.color,1);//왼쪽 사선 탄환 생성
		new EnemyBullet(this.x + this.width/2, this.y, this.color,2);//가운데 탄환 생성
		new EnemyBullet(this.x + this.width/2, this.y, this.color,3);//오른쪽 사선탄환 생성
	};


//여기부턴 아이템 생성 부분
var Item=function(){
	this.width = 20;
	this.height = 20;
	//this.mode=0;//적의 공격방식을 관리하는 변수 //0=기본 1=
	this.x = Game.random(0, (Game.c.width - this.width));
	this.y = Game.random(10, 40);
	this.vy = 2;//적은 위아래로 내려가기 때문에 그 움직이는 수치를 나타냄
	this.index = Game.itemindex;			//적 배열의 인덱스 설정
	Game.items[Game.itemindex] = this;   //배열에 배정
	Game.itemindex++;						//다음을 위해 enemy값 설정
	this.speed = Game.random(2, 3);  //옆으로 움직이는 속도 값
	this.color = "hsl("+ Game.random(0, 360) +", 60%, 50%)";//랜덤값으로 컬러를 설정
};
//


/////////////////////////////////////////////////////////

Item.prototype.draw = function(){//탄환을 그릴때의 함수
	Game.ctx.drawImage(img_item, this.x, this.y);// 이부분이 이미지 적용시키는 부분  ####
		//Game.ctx.fillStyle = this.color;//색을 배정하고
		//Game.ctx.fillRect(this.x, this.y, this.width, this.height);//fiilrect로 사각형 그리기
};


Item.prototype.update = function(){//탄환을 그리기 위해 해야되는 함수
		this.y += this.vy;//위치를 vy만큼 내려가게하고
		if(this.y > Game.c.height){//캔버스를 벗어나면,
			//delete Game.items[this.index];//삭제시킨다
		}
};
//아이템 끝


var Player = function(){//처음 플레이어 생성자
	this.width = 50;//넓이는 60
	this.height = 40;// 플레이어 블럭의 높이를 의미한다 20쯤
	this.x = Game.c.width/2 - this.width/2;//정가운데에서 시작
	this.y = Game.c.height - this.height;//캔버스의 위치 520을 의미
	this.movingLeft = false;
	this.movingRight = false;
	this.movingUp = false;
	this.movingDown = false;
	this.speed = 8;//한 프레임당 움직이는 범위 8
	this.invincible = false;// 깜빡이는 여부
	this.color = "white";// 본체블럭의 색
};


Player.prototype.die = function(){// 플레이어가 적탄환에 충돌했을대 발생
	if(Game.life < Game.maxLives){//피가 남아 있다면
		Game.invincibleMode(2000);  //깜빡이게 하고
 		Game.life++;//죽음에 가까워짐
	} else {//피가 없다면
		Game.pause();//멈추고
		Game.gameOver();//게임오버시킨다
	}
	diesound.currentTime = 0;
	diesound.play();
};


Player.prototype.draw = function(){//loop에서 그리는 함수
	Game.ctx.drawImage(img_player, this.x, this.y);// 이부분이 이미지 적용시키는 부분
//	Game.ctx.fillStyle = this.color;// player.color 색으로 정하고
//	Game.ctx.fillRect(this.x, this.y, this.width, this.height);//본체 그림
};


Player.prototype.update = function(){//loop에서 업데이트 할때 draw보단 나중에 실행됨
	if(this.movingLeft && this.x > 0){//movingleft값이 true고 플레이어의 왼쪽선이 캔버스 왼쪽보다는 클때
		this.x -= this.speed; //speed값만큼 왼쪽으로이동
	}
	if(this.movingRight && this.x + this.width < Game.c.width){//movingright가 true고 플레이어의 오른쪽선이 캔버스를 벗어나지 않는다면
		this.x += this.speed; //
	}
	if(this.movingUp && this.y > 0){//up값이 true고 플레이어의 왼쪽선이 캔버스 왼쪽보다는 클때  //game height 가 800 this y 가 20
		this.y -= this.speed; //speed값만큼 왼쪽으로이동
	}
	if(this.movingDown && this.y + this.height < Game.c.height){//movingDown값이 true고 플레이어의 왼쪽선이 캔버스 왼쪽보다는 클때
		this.y += this.speed; //speed값만큼 왼쪽으로이동
	}
	if(Game.shooting && Game.currentFrame % 10 === 0){// 키가 눌려서 shooting값이 true고 frame이 일정 간격만큼 되었을때
		this.shoot();//탄환을 발사하는 함수 실행
	}
	for(var i in Game.enemyBullets){//적 탄환전부에대해 충돌검사 하는 부분
		var currentBullet = Game.enemyBullets[i];//임시변수 currentBullet에 당시 enemyBullet을 저장
		if(Game.collision(currentBullet, this) && !Game.player.invincible){//플레이어가 깜빡이지 않고 충돌된 상태면
			this.die();//충돌함수 시작
			delete Game.enemyBullets[i];//해당 탄환 삭제
		}
	}
	if(Game.itemcreate==true){//플레이어와 아이템이 만났을때의 설정
		if(Game.collision(Game.items[Game.itemindex-1],this)){
			Game.mode=1;
			Game.itemcreate=false;
			setTimeout(function(){//적은 죽고난후 2초뒤에 새로생긴다
				Game.mode=0;
			}, 5000);
			delete Game.items[Game.itemindex-1];
		}
	}
};


Player.prototype.shoot = function(){//플레이어 탄환 생성 함수
	if(Game.mode==0) {
		Game.bullets[Game.bulletIndex] = new Bullet(this.x + this.width / 2,this.y, 0); //현 player 의
		Game.bulletIndex++;
	}
	else if (Game.mode==1){
		Game.bullets[Game.bulletIndex]=new Bullet(this.x+this.width/2,this.y,plu);
		Game.bulletIndex++;
		Game.bullets[Game.bulletIndex]=new Bullet(this.x+this.width/2,this.y,minu);
		Game.bulletIndex++;
	}
	else if(Game.mode==2){
		Game.bullets[Game.bulletIndex]=new Bullet(this.x+this.width/2,this.y,plu);
		Game.bulletIndex++;
		Game.bullets[Game.bulletIndex]=new Bullet(this.x+this.width/2,this.y,minu);
		Game.bulletIndex++;

	}
};






var Bullet = function(x,y,mode){  //플레이어의 탄을 의미
	this.width = 13;
	this.height = 18;//이것도 탄환의 높이를 의미
	this.x = x+mode;	//입력받은 x의 값 ->보통 입력으로 플레이어의 현재 x위치를 줌
	this.y = y;//처음 탄환의 y위치를 의미 처음엔 y좌표는 플레이어 블럭의 밑선부터 시작
	this.vy = 8;//y축에서 이동하는 크기-->이걸 바꾸면 플레이어의 탄환이 한번에 더 많이 움직인다= 탄속
	this.index = Game.bulletIndex;//현재 존재하는 탄환중 자기가 몇번째인지를 나타내는 변수
	this.active = true;
	this.color = "white";//탄환의 색
	this.lr=(mode>0)?1:-1;
	if(Game.mode==2){
		this.x-=mode;
	}

	
};


Bullet.prototype.draw = function(){
	//Game.ctx.fillStyle = this.color;//탄환의 색을 준비하고
//	Game.ctx.fillRect(this.x, this.y, this.width, this.height);//탄환의 속성으로 사각형 그리기
	Game.ctx.drawImage(img_playerbullet, this.x, this.y);// 이부분이 이미지 적용시키는 부분
};


Bullet.prototype.update = function(){//탄환의 위치를 업데이트
	if(Game.mode==0||Game.mode==1) {
		this.y -= this.vy;//y값을 감소시키면 캔버스에선 위로 올라감
		if (this.y < 0) {//캔버스를 넘어가면 삭제시킨다
			delete Game.bullets[this.index];
		}
	}
	else if(Game.mode==2){
		this.y -= this.vy;//y값을 감소시키면 캔버스에선 위로 올라감
		if (this.y < 0) {//캔버스를 넘어가면 삭제시킨다
			delete Game.bullets[this.index];
		}
		this.x+=this.lr*3;

	}
};






var Enemy = function(){//적이 생성됐을때 사용하는 함수 대부분은 플레이어와 비슷하다
	this.width = 30;
	this.height = 30;
	this.mode=0;//적의 공격방식을 관리하는 변수 //0=기본 1=
	this.x = Game.random(0, (Game.c.width - this.width));
	this.y = Game.random(10, 40);
	this.vy = Game.random(1, 3) * .1;//적은 위아래로 내려가기 때문에 그 움직이는 수치를 나타냄
	this.index = Game.enemyIndex;			//적 배열의 인덱스 설정
	Game.enemies[Game.enemyIndex] = this;   //배열에 배정
	Game.enemyIndex++;						//다음을 위해 enemy값 설정
	this.speed = Game.random(2, 3);  //옆으로 움직이는 속도 값
	this.shootingSpeed = Game.random(30, 80);		//발사하는 주기를 정하는 값
	this.movingLeft = Math.random() < 0.5 ? true : false;//		처음에 반반확률로 왼쪽으로 갈지 오른쪽으로갈지 정한다.
	this.color = "hsl("+ Game.random(0, 360) +", 60%, 50%)";//랜덤값으로 컬러를 설정
	
};


Enemy.prototype.draw = function(){
	Game.ctx.drawImage(img_enemy, this.x, this.y);// 이부분이 이미지 적용시키는 부분
	//Game.ctx.fillStyle = this.color;//var Enemy fucntion에서 설정한 값으로 스타일에 저장하고
	//Game.ctx.fillRect(this.x, this.y, this.width, this.height);//그걸로 네모 그림
};


Enemy.prototype.update = function(){
	if(this.movingLeft){//왼쪽으로 이동하는 경우 --> movingleft값이 true일때
		if(this.x > 0){//네모의 왼쪽 선이 캔버스의 왼쪽 끝과 닿았는지 확인하고
			this.x -= this.speed;//왼쪽으로 speed값만큼 이동
			this.y += this.vy;//왼쪽으로 갈땐 살짝 아래로 내려가며 이동
		} else {//왼쪽 끝인 경우에 한틱 멈추고
			this.movingLeft = false;//값을 바꿈
		}
	} else {//오른쪽으로 이동하는 경우 -->false
		if(this.x + this.width < Game.c.width){//네모의 오른쪽선이 캔버스의 오른쪽 끝과 닿았는지 확인
			this.x += this.speed;
			this.y += this.vy;
		} else {//반대로 끝에 닿았다면 한틱쉬고 movingleft값을 true로
			this.movingLeft = true;
		}
	}
	
	for(var i in Game.bullets){//이동한후에 모든 플레이어의 탄환마다 맞았는지 검사를 실행한다.
		var currentBullet = Game.bullets[i];//예비변수 currentBullet에 탄환중 하나를 배정하고
		if(Game.collision(currentBullet, this)){//충돌검사하는 함수 collision을 실행
			this.die();
			delete Game.bullets[i];
		}
	} 
};

Enemy.prototype.die = function(){
  this.explode();
  delete Game.enemies[this.index];
  Game.score += 15;
 // Game.sscore.value=this.c.height;
  Game.enemiesAlive = Game.enemiesAlive > 1 ? Game.enemiesAlive - 1 : 0;
  if(Game.enemiesAlive < Game.maxEnemies){
  	Game.enemiesAlive++;
  	setTimeout(function(){//적은 죽고난후 2초뒤에 새로생긴다
  		new Enemy();
	  }, 1000);
	}
  
};

Enemy.prototype.explode = function(){//죽었을때 터지는 효과 함수
	for(var i=0; i<Game.maxParticles; i++){//한명이 죽을때 맥스파티클만큼의 작은 알갱이를 발생시킨다
    new Particle(this.x + this.width/2, this.y, this.color);//적의 위치와 함께 적의 색을 보내서 파티클(터지는효과)실행
  }
	diesound.currentTime = 0;
	diesound.play();
};

Enemy.prototype.shoot = function(){//적이 탄환을 쏠때, 적의탄환생성함수
	new EnemyBullet(this.x + this.width/2, this.y, this.color,0);//이때의 x는 블럭의 가운데고, y는 밑선 기준임
};

var EnemyBullet = function(x, y, color,bossi){//탄환 생성시 시작되는 함수 bossi는 보스의 탄인지 확인하는 함수
	this.width = 11;//넓이
	this.height = 15;//높이
	this.x = x;//생성시 받은 위치 = (적 블럭의 정가운데 , 적블럭의 밑부분) 을 받는다
	this.y = y;
	this.vy = 4;
	this.vx=0;
	this.color = color;
	this.bossi=bossi;//보스의 탄인지 구분해주는 변수 0이면 일반 적, 아니면 보스의탄
	this.index = Game.enemyBulletIndex;//탄환 관리하는 인덱스
	Game.enemyBullets[Game.enemyBulletIndex] = this;//전체적으로 적의 탄환을 관리하는 배열에 자신을 배정
	Game.enemyBulletIndex++;//다음에 배정될 탄환을 위해 미리 1증가시키는 모습
	if(Game.enemymode===2){//에너미모드 변수가 2이면
		this.vy=Game.random(2,6);// 처음 속도값을 랜덤으로 정해버린다.
	}
	else if(this.bossi!==0){//보스의 탄이라면
		if(this.bossi===1){
			this.vx=-1;
		}
		else if(this.bossi===2){
			this.vx=0;
		}
		else if(this.bossi===3){
			this.vx=1;
		}
	}

};

EnemyBullet.prototype.draw = function(){//탄환을 그릴때의 함수
	if(this.bossi===0) {//일반 적의 탄이라면
		//Game.ctx.fillStyle = this.color;//색을 배정하고
		//Game.ctx.fillRect(this.x, this.y, this.width, this.height);//fiilrect로 사각형 그리기
		Game.ctx.drawImage(img_enemybullet, this.x, this.y);// 이부분이 이미지 적용시키는 부분
	}
	else if(this.bossi!==0){//보스의 탄이라면
		if(this.vx>0){//왼쪽으로 가는 탄환의 경우
			Game.ctx.drawImage(img_bossbullet, this.x, this.y);// 이부분이 이미지 적용시키는 부분
		}
		else if(this.vx<0)//오른쪽으로 가는 탄환의 경우
		{
			Game.ctx.drawImage(img_bossbullet, this.x, this.y);// 이부분이 이미지 적용시키는 부분
		}
		else{//그냥 밑으로 내려가는 탄환의 경우
			Game.ctx.drawImage(img_bossbullet, this.x, this.y);// 이부분이 이미지 적용시키는 부분
		}
		//Game.ctx.fillStyle = 'white';//색을 배정하고
		//Game.ctx.fillRect(this.x, this.y, this.width, this.height);//fiilrect로 사각형 그리기
		Game.ctx.drawImage(img_bossbullet, this.x, this.y);// 이부분이 이미지 적용시키는 부분

	}
};

EnemyBullet.prototype.update = function(){//탄환을 그리기 위해 해야되는 함수

	if(this.bossi!==0){//보스의 탄이라면 x도 이동시킨다.
		this.x +=this.vx;
		this.y +=this.vy;
	}
	//에너미 모드 변수에 따라 내려오는 속도가 다르다.
	else if(Game.enemymode!=1) {
		this.y += this.vy;//위치를 vy만큼 내려가게하고
	}
	else if(Game.enemymode==1){//에너미모드가 1일땐 매 번 랜덤함수를 돌린다.
		this.y+=Game.random(-4	,9);
	}




	if(this.y > Game.c.height || this.x<0 || this.x>Game.c.width){//캔버스를 벗어나면,
		delete Game.enemyBullets[this.index];//삭제시킨다
	}
};




var Particle = function(x, y, color){//적이 죽을때 펑 터지는 모습을 만드는 작은 조각 함수
    this.x = x;//현재 적의 위치
    this.y = y;//를 기준으로
    this.vx = Game.random(-5, 5);//속도와 세기를 랜덤으로 정한다
    this.vy = Game.random(-5, 5);//+-에 따라 방향이, 크기에 따라 속도가 정해진다
    this.color = color || "orange";
    Game.particles[Game.particleIndex] = this;//파티클을 관리하는 배열에 자신을 배정
    this.id = Game.particleIndex;//자신이 몇번째 파티클인지 설정
    Game.particleIndex++;
    this.life = 0;
    this.gravity = .05;
    this.size = 40;
    this.maxlife = 100;
  }

  Particle.prototype.draw = function(){//파티클을 그리는 함수
    this.x += this.vx;
    this.y += this.vy;
    this.vy += this.gravity;
    this.size *= .89;//점점 작아지게 설정
    Game.ctx.fillStyle = this.color;
    Game.ctx.fillRect(this.x, this.y, this.size, this.size);
    this.life++;
    if(this.life >= this.maxlife){
      delete Game.particles[this.id];
    }
  };

Game.init();


}(window));
from django.apps import AppConfig


class CrowConfig(AppConfig):
    name = 'crow'

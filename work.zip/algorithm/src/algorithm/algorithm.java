package algorithm;

public class algorithm {
	
	private int al_num;
	public int getAl_num() {
		return al_num;
	}
	public void setAl_num(int al_num) {
		this.al_num = al_num;
	}
	public String getAl_examiner() {
		return al_examiner;
	}
	public void setAl_examiner(String al_examiner) {
		this.al_examiner = al_examiner;
	}
	public String getAl_name() {
		return al_name;
	}
	public void setAl_name(String al_name) {
		this.al_name = al_name;
	}
	public String getAl_simple() {
		return al_simple;
	}
	public void setAl_simple(String al_simple) {
		this.al_simple = al_simple;
	}
	public String getAl_detail() {
		return al_detail;
	}
	public void setAl_detail(String al_detail) {
		this.al_detail = al_detail;
	}
	public int getAl_prequency() {
		return al_prequency;
	}
	public void setAl_prequency(int al_prequency) {
		this.al_prequency = al_prequency;
	}
	private String al_examiner;
	private String al_name;
	private String al_simple;
	private String al_detail;
	private int al_prequency;
	
	
}
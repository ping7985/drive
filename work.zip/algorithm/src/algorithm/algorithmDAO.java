package algorithm;

import java.sql.*;
import java.util.*;

public class algorithmDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public algorithmDAO() { 
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS"; 
			String dbID = "root";
			String dbPassword = "wndls95!@";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace(); 
		}
	}

	public int insertDB(algorithm algorithmD, String examiner) {//踰덊샇,異쒖젣�옄, �븣怨좊━利� �씠由�, �젣紐�, �궡�슜, �옲�겕, �삁�젣 �엯�젰 �삁�젣異쒕젰
		String sql = "SELECT * FROM USER WHERE userID = '" + examiner + "'";
		try {		
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				sql = "insert into ALGORITHM_TABLE(al_examiner, al_name, al_simple, al_detail, al_prequency) VALUES (?, ?, ?, ?, ?)";

				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, algorithmD.getAl_examiner());
				pstmt.setString(2, algorithmD.getAl_name());
				pstmt.setString(3, algorithmD.getAl_simple());
				pstmt.setString(4, algorithmD.getAl_detail());
				pstmt.setInt(5, algorithmD.getAl_prequency());
				pstmt.executeUpdate();
				return 1;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return 0;
			}
			return -1;
	}
	public ArrayList<algorithm> getalgorithmlistDB() {
		ArrayList<algorithm> datas = new ArrayList<algorithm>();
	
		String sql = "SELECT * FROM ALGORITHM_TABLE";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				algorithm algorithmD = new algorithm(); 
				algorithmD.setAl_num(rs.getInt("al_num"));
				algorithmD.setAl_examiner(rs.getString("al_examiner"));
				algorithmD.setAl_name(rs.getString("al_name"));
				algorithmD.setAl_prequency(rs.getInt("al_prequency"));
				algorithmD.setAl_simple(rs.getString("al_simple"));
				algorithmD.setAl_detail(rs.getString("al_detail"));			
				datas.add(algorithmD);
			}
			rs.close();
			
		} catch (SQLException e) {
		e.printStackTrace();
		}
		
	return datas;
	}

	public int getAlgorithmNum(algorithm algorithmD, String examiner) {
		String sql = "SELECT * FROM USER WHERE userID='"+ examiner + "'";
		int num;
		try {
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			if(rs.next()) {
				sql ="SELECT * FROM ALGORITHM_TABLE WHERE al_examiner=? AND al_name=?";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, algorithmD.getAl_examiner());
				pstmt.setString(2, algorithmD.getAl_name());
				rs = pstmt.executeQuery();
				if(rs.next()) {
					num = rs.getInt("al_num");
					return num;
				}
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return -1;
	}
	public algorithm getalgorithmInfo(int num) {
		String sql = "SELECT * FROM ALGORITHM_TABLE WHERE al_num='"+ num + "'";
		algorithm algorithmD=new algorithm();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				algorithmD.setAl_num(rs.getInt("al_num"));
				algorithmD.setAl_examiner(rs.getString("al_examiner"));
				algorithmD.setAl_name(rs.getString("al_name"));
				algorithmD.setAl_prequency(rs.getInt("al_prequency"));
				algorithmD.setAl_simple(rs.getString("al_simple"));
				algorithmD.setAl_detail(rs.getString("al_detail"));
				return algorithmD;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return algorithmD;
	}
	
	public ArrayList<algorithm> getalgorithmDB(int num) {
		ArrayList<algorithm> datass = new ArrayList<algorithm>();
	
		String sql = "SELECT * FROM ALGORITHM_TABLE WHERE al_num='"+ num + "'";
		try {
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			while(rs.next()) {
				algorithm algorithmD= new algorithm();
				
				algorithmD.setAl_num(rs.getInt("al_num"));
				algorithmD.setAl_examiner(rs.getString("al_examiner"));
				algorithmD.setAl_name(rs.getString("al_name"));
				algorithmD.setAl_simple(rs.getString("al_simple"));
				algorithmD.setAl_detail(rs.getString("al_detail"));
							
				datass.add(algorithmD);
			}
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return datass;
	}
}
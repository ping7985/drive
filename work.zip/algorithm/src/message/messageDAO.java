package message;

import java.sql.*;
import java.util.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class messageDAO {
	private Connection conn; // connection:db�������ϰ� ���ִ� ��ü
	private PreparedStatement pstmt;
	private ResultSet rs;
	// mysql�� ������ �ִ� �κ�
	public messageDAO() { // ������ ����ɶ����� �ڵ����� db������ �̷�� �� �� �ֵ�����
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS"; // localhost:3306 ��Ʈ�� ��ǻ�ͼ�ġ�� mysql�ּ�
			String dbID = "root";
			String dbPassword = "wndls95!@";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace(); // ������ �������� ���
		}
	}
	public boolean deleteDB(int me_num) {
		
		String sql ="delete from MESSAGE_TABLE where me_num=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,me_num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public int insertDB(message messageinfo, String receiver) {
		String sql = "SELECT * FROM USER WHERE userID='"+ receiver + "'";
		try {
		
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			if(rs.next()) {
			sql ="insert into MESSAGE_TABLE(me_sendid, me_receiveid, me_title, me_content, check_read) values(?,?,?,?,?)";
		
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, messageinfo.getMe_sendid());
			pstmt.setString(2, messageinfo.getMe_receiveid());
			pstmt.setString(3, messageinfo.getMe_title());
			pstmt.setString(4, messageinfo.getMe_content());
			pstmt.setBoolean(5, false);
			pstmt.executeUpdate();
			return 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return -1;
	}
	public boolean updateDB(message messageinfo,int num) {
		
		String sql ="update MESSAGE_TABLE set me_sendid=?, me_receiveid=?,me_title=?, me_content=?, check_read=? where me_num=?";		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,messageinfo.getMe_sendid());
			pstmt.setString(2,messageinfo.getMe_receiveid());
			pstmt.setString(3,messageinfo.getMe_title());
			pstmt.setString(4,messageinfo.getMe_content());
			pstmt.setBoolean(5, false);
			pstmt.setInt(6,num);
			pstmt.executeUpdate();
			System.out.println(messageinfo.getMe_num());
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public message getMessage(int num) {
		
		String sql ="SELECT * FROM MESSAGE_TABLE WHERE me_num='"+ num + "'";
		message messageinfo = new message();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				messageinfo.setMe_num(rs.getInt("me_num"));
				messageinfo.setMe_sendid(rs.getString("me_sendid"));
				messageinfo.setMe_receiveid(rs.getString("me_receiveid"));
				messageinfo.setMe_title(rs.getString("me_title"));
				messageinfo.setMe_content(rs.getString("me_content"));
				messageinfo.setCheck_read(true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return messageinfo;
	}
	public ArrayList<message> getDBList(String id) {
		ArrayList<message> datas = new ArrayList<message>();
		
		String sql = "SELECT * FROM MESSAGE_TABLE WHERE me_receiveid='"+ id + "'";
		try {
		
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			while(rs.next()) {
				message messageinfo = new message();
				messageinfo.setMe_num(rs.getInt("me_num"));
				messageinfo.setMe_sendid(rs.getString("me_sendid"));
				messageinfo.setMe_receiveid(rs.getString("me_receiveid"));
				messageinfo.setMe_title(rs.getString("me_title"));
				messageinfo.setMe_content(rs.getString("me_content"));
				messageinfo.setCheck_read(rs.getBoolean("check_read"));
				datas.add(messageinfo);
			}
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return datas;
	}
	public ArrayList<message> checkDBList(String id) {
		ArrayList<message> datas = new ArrayList<message>();
		
		String sql = "SELECT * FROM MESSAGE_TABLE WHERE me_sendid='"+ id + "'";
		try {
		
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			while(rs.next()) {
				message messageinfo = new message();
				
				messageinfo.setMe_num(rs.getInt("me_num"));
				messageinfo.setMe_sendid(rs.getString("me_sendid"));
				messageinfo.setMe_receiveid(rs.getString("me_receiveid"));
				messageinfo.setMe_title(rs.getString("me_title"));
				messageinfo.setMe_content(rs.getString("me_content"));
				messageinfo.setCheck_read(rs.getBoolean("check_read"));
				datas.add(messageinfo);
			}
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return datas;
	}
}

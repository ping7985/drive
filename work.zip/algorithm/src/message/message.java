package message;

public class message {
	
	private int me_num;
	private String me_sendid;
	private String me_receiveid;
	private String me_title;
	private String me_content;
	private boolean check_read = false;
	
	public String getMe_title() {
		return me_title;
	}
	public void setMe_title(String me_title) {
		this.me_title = me_title;
	}
	public int getMe_num() {
		return me_num;
	}
	public void setMe_num(int me_num) {
		this.me_num = me_num;
	}
	public String getMe_sendid() {
		return me_sendid;
	}
	public void setMe_sendid(String me_sendid) {
		this.me_sendid = me_sendid;
	}
	public String getMe_receiveid() {
		return me_receiveid;
	}
	public void setMe_receiveid(String me_receiveid) {
		this.me_receiveid = me_receiveid;
	}
	public String getMe_content() {
		return me_content;
	}
	public void setMe_content(String me_content) {
		this.me_content = me_content;
	}
	public boolean isCheck_read() {
		return check_read;
	}
	public void setCheck_read(boolean check_read) {
		this.check_read = check_read;
	}
	
	
}

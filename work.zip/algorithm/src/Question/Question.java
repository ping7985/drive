package Question;

public class Question {
	
	private int qu_num;
	private String qu_writer;
	private String qu_algorithm;
	private String qu_title;
	private String qu_content;
	private String qu_img;
	private int qu_rank;
	
	public void setQu_rank(int qu_rank) {
		this.qu_rank = qu_rank;
	}
	public int getQu_num() {
		return qu_num;
	}
	public void setQu_num(int qu_num) {
		this.qu_num = qu_num;
	}
	public int getQu_rank() {
		return qu_rank;
	}
	public String getQu_writer() {
		return qu_writer;
	}
	public void setQu_writer(String qu_writer) {
		this.qu_writer = qu_writer;
	}
	public String getQu_algorithm() {
		return qu_algorithm;
	}
	public void setQu_algorithm(String qu_algorithm) {
		this.qu_algorithm = qu_algorithm;
	}
	public String getQu_title() {
		return qu_title;
	}
	public void setQu_title(String qu_title) {
		this.qu_title = qu_title;
	}
	public String getQu_content() {
		return qu_content;
	}
	public void setQu_content(String qu_content) {
		this.qu_content = qu_content;
	}
	public String getQu_img() {
		return qu_img;
	}
	public void setQu_img(String qu_img) {
		this.qu_img = qu_img;
	}
	
	
}

package Question;

import java.sql.*;
import java.util.*;

public class QuestionDAO {
	private Connection conn; // connection:db�������ϰ� ���ִ� ��ü
	private PreparedStatement pstmt;
	private ResultSet rs;
	// mysql�� ������ �ִ� �κ�
	public QuestionDAO() { // ������ ����ɶ����� �ڵ����� db������ �̷�� �� �� �ֵ�����
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS"; // localhost:3306 ��Ʈ�� ��ǻ�ͼ�ġ�� mysql�ּ�
			String dbID = "root";
			String dbPassword = "wndls95!@";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace(); // ������ �������� ���
		}
	}
	public int insertDB(Question questioninfo, String writer) {
		String sql = "SELECT * FROM USER WHERE userID='"+ writer + "'";
		try {
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			if(rs.next()) {
			sql ="insert into QUESTION_TABLE(qu_writer, qu_title, qu_content, qu_algorithm, qu_rank, qu_img) values(?,?,?,?,?,?)";
		
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, questioninfo.getQu_writer());
			pstmt.setString(2, questioninfo.getQu_title());
			pstmt.setString(3, questioninfo.getQu_content());
			pstmt.setString(4, questioninfo.getQu_algorithm());
			pstmt.setInt(5, questioninfo.getQu_rank());
			pstmt.setString(6, questioninfo.getQu_img());
			pstmt.executeUpdate();
			
			return 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return -1;
	}
	public int getQuestionNum(Question questioninfo, String writer) {
		String sql = "SELECT * FROM USER WHERE userID='"+ writer + "'";
		int num ;
		try {
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			if(rs.next()) {
				sql ="SELECT * FROM QUESTION_TABLE WHERE qu_writer=? AND qu_title=?";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, questioninfo.getQu_writer());
				pstmt.setString(2, questioninfo.getQu_title());
				rs = pstmt.executeQuery();
				if(rs.next()) {
					num = rs.getInt("qu_num");
					return num;
				}
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return -1;
	}
	public boolean setTestcaseDB(String input,String output,int qu_num) {
		
		String sql = "SELECT * FROM QUESTION_TABLE WHERE qu_num='"+ qu_num + "'";
		try {
		
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			if(rs.next()) {
				sql ="insert into TESTCASE_TABLE(tc_num, tc_answer, tc_input) values(?,?,?)";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, qu_num);
				pstmt.setString(2, output);
				pstmt.setString(3, input);
				pstmt.executeUpdate();
				return true;
			}
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	public Question getQuestionInfo(int qu_num) {
		String sql = "SELECT * FROM QUESTION_TABLE WHERE qu_num='"+ qu_num + "'";
		Question questioninfo=new Question();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				questioninfo.setQu_num(rs.getInt("qu_num"));
				questioninfo.setQu_algorithm(rs.getString("qu_algorithm"));
				questioninfo.setQu_writer(rs.getString("qu_writer"));
				questioninfo.setQu_title(rs.getString("qu_title"));
				questioninfo.setQu_content(rs.getString("qu_content"));
				questioninfo.setQu_rank(rs.getInt("qu_rank"));
				questioninfo.setQu_img(rs.getString("qu_img"));
				return questioninfo;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questioninfo;
	}
	public boolean checkQuestion(String input, String output, int qu_num) {
		String SQL = "SELECT * FROM TESTCASE_TABLE WHERE tc_num='"+ qu_num + "'";
		try {
			pstmt = conn.prepareStatement(SQL);
			// rs:result set �� �������
			rs = pstmt.executeQuery();
			// ����� �����Ѵٸ� ����
			while(rs.next()) {
				if (rs.getString(1).equals(input)) {
					if(rs.getString(2).equals(output))
						return true; 
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; // �����ͺ��̽� ������ �ǹ�
	}
	public ArrayList<Integer> getsolveQuestionnum(String userID)
	{
		ArrayList<Integer> datas = new ArrayList<Integer>();
		
		String sql = "SELECT * FROM NOTSOLVE_TABLE WHERE so_user='"+ userID + "'";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int questionnum;
				questionnum = rs.getInt("so_num");
				datas.add(questionnum);
			}
			rs.close();
			
		} catch (SQLException e) {
		e.printStackTrace();
		}
		
	return datas;
	}
	public ArrayList<Question> getQuestionDB(int rank) {
		ArrayList<Question> datas = new ArrayList<Question>();
	
		String sql = "SELECT * FROM QUESTION_TABLE WHERE qu_rank='"+ rank + "'";
		try {
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			while(rs.next()) {
				Question questioninfo = new Question();
				
				questioninfo.setQu_num(rs.getInt("qu_num"));
				questioninfo.setQu_writer(rs.getString("qu_writer"));
				questioninfo.setQu_title(rs.getString("qu_title"));
				questioninfo.setQu_content(rs.getString("qu_content"));
				questioninfo.setQu_algorithm(rs.getString("qu_algorithm"));
				questioninfo.setQu_img(rs.getString("qu_img"));
				questioninfo.setQu_rank(rs.getInt("qu_rank"));
				
				datas.add(questioninfo);
			}
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return datas;
	}
	public void wrongAnswor(String userId,int qu_num) {
		String sql = "SELECT * FROM NOTSOLVE_TABLE WHERE so_user='"+ userId + "' AND so_num='"+ qu_num + "'";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
			
			}else {
				sql ="insert into NOTSOLVE_TABLE(so_user, so_num) values(?,?)";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userId);
				pstmt.setInt(2, qu_num);
				pstmt.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void collectAnswor(String userId,int qu_num) {
		String sql = "SELECT * FROM NOTSOLVE_TABLE WHERE so_user='"+ userId + "' AND so_num='"+ qu_num + "'";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
			sql ="delete from NOTSOLVE_TABLE where so_user=? AND so_num='"+ qu_num +"'";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Testcase> getQuestiontestcaseDB(int qu_num) {
		ArrayList<Testcase> datas = new ArrayList<Testcase>();
	
		String sql = "SELECT * FROM TESTCASE_TABLE WHERE tc_num='"+ qu_num + "'";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Testcase testcaseinfo = new Testcase();
			
				testcaseinfo.setTc_num(rs.getInt("tc_num"));
				testcaseinfo.setTc_input(rs.getString("tc_input"));
				testcaseinfo.setTc_answer(rs.getString("tc_answer"));
			
				datas.add(testcaseinfo);
			}
			rs.close();
			
		} catch (SQLException e) {
		e.printStackTrace();
		}
		
	return datas;
	}
}
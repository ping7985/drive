package Question;

public class Testcase {
	int tc_num;
	String tc_answer;
	String tc_input;
	
	public int getTc_num() {
		return tc_num;
	}
	public void setTc_num(int tc_num) {
		this.tc_num = tc_num;
	}
	public String getTc_answer() {
		return tc_answer;
	}
	public void setTc_answer(String tc_answer) {
		this.tc_answer = tc_answer;
	}
	public String getTc_input() {
		return tc_input;
	}
	public void setTc_input(String tc_input) {
		this.tc_input = tc_input;
	}
}

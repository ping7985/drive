// This file is a "Hello, world!" in Go language for wandbox.
package main

import (
        "fmt"
)

func main() {
        fmt.Println("Hello, Wandbox!")
}

// Go language references:
//   https://golang.org/pkg/

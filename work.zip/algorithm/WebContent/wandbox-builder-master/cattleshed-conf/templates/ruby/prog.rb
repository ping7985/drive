# This file is a "Hello, world!" in Ruby language by ruby for wandbox.

puts "Hello, Wandbox!"

# Ruby reference:
#   https://docs.ruby-lang.org/

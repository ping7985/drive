// This file is a "Hello, world!" in Java language by OpenJDK for wandbox.

class Wandbox
{
    public static void main(String[] args)
    {
        System.out.println("Hello, Wandbox!");
    }
}

// OpenJDK reference:
//   http://openjdk.java.net/

// Java language references:
//   http://docs.oracle.com/javase

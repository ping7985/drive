# This file is a "Hello, world!" in Python language by PyPy for wandbox.

print("Hello, world!")

# PyPy reference:
#   https://pypy.org/

# Python language reference:
#   https://www.python.org/

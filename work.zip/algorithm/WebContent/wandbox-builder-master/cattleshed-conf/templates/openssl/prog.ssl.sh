# This file is a "Hello, world!" in OpenSSL for wandbox.
openssl genrsa 2048

# OpenSSL documents:
#   https://www.openssl.org/docs/
#   run `openssl help` on this page

#!/bin/bash
# This file is a "Hello, world!" in Bash script for wandbox.
echo Hello, Wandbox!

# Bash script references:
#   https://www.gnu.org/software/bash/manual/bashref.html
#   http://shellscript.sunone.me ( Japanese )

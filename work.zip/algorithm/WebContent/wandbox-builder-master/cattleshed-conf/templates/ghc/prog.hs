-- This file is a "Hello, world!" in Haskell language by GHC for wandbox.

main = putStrLn "Hello, Wandbox!"

-- GHC reference:
--   https://www.haskell.org/ghc/

-- Haskell language references:
--   https://www.haskell.org/
--   https://wiki.haskell.org/

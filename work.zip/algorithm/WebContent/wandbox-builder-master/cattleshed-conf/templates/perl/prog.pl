# This file is a "Hello, world!" in Perl language for wandbox.

print "Hello, Wandbox!\n";

# Perl language references:
#   http://perldoc.perl.org/

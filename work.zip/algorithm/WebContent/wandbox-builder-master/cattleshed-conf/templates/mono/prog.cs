// This file is a "Hello, world!" in C# language by Mono for wandbox.
using System;

namespace Wandbox
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Wandbox!");
        }
    }
}

// Mono references:
//   http://www.mono-project.com/

// C# language references:
//   https://msdn.microsoft.com/library/618ayhy6.aspx

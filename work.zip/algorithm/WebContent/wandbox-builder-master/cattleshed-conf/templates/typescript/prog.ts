const n: string = "Hello, Wandbox!";
console.log(n);

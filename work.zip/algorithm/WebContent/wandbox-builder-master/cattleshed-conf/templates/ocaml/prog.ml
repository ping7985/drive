(* This file is a "Hello, world!" in OCaml language for wandbox. *)

print_endline "Hello, Wandbox!"

(* OCaml language references:
   https://ocaml.org/
 *)

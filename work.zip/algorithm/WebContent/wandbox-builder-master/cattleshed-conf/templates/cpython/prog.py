# This file is a "Hello, world!" in Python language by CPython for wandbox.

print("Hello, world!")

# CPython references:
#   https://www.python.org/

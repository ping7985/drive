# This file is a "Hello, world!" in Ruby language by mruby for wandbox.

puts "Hello, Wandbox!"

# mruby reference:
#   https://github.com/mruby/mruby

# Ruby language references:
#   https://docs.ruby-lang.org/

// This file is a "Hello, world!" in Groovy language for wandbox.

println "Hello Wandbox!"

// Groovy language references:
//   http://groovy-lang.org/

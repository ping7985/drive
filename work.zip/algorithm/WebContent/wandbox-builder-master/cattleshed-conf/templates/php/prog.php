<?php
// This file is a "Hello, world!" in PHP for wandbox.
print("Hello, Wandbox!\n");
// PHP references:
//   http://php.net

// This file is a "Hello, world!" in Apple Swift language for wandbox.
print("Hello, Wandbox!");

// Apple Swift language references:
//   http://www.apple.com/swift/

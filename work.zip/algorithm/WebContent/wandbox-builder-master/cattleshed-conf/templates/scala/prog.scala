// This file is a "Hello, world!" in Scala language for wandbox.

object Wandbox {
  def main(args: Array[String]): Unit = {
    println("Hello, Wandbox!")
  }
}

// Scala language references:
//   http://www.scala-lang.org

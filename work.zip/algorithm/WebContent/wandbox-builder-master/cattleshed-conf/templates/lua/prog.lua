-- This file is a "Hello, world!" in Lua language for wandbox.

print "Hello, Wandbox!"

-- Lua language references:
--   https://www.lua.org/

-- This file is a "Hello, world!" in SQL by SQLite for wandbox.

SELECT 'Hello, Wandbox!';

-- SQLite reference:
-- http://www.sqlite.org/

-- SQL language references:
--   https://www.mysql.com
--   https://msdn.microsoft.com/library/dn198336.aspx

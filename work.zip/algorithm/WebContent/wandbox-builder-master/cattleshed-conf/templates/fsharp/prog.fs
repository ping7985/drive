// This file is a "Hello, world!" in F# language for Wandbox.

module Wandbox =
    let main() = printfn "Hello, Wandbox!"

Wandbox.main()

// F# references:
//   https://docs.microsoft.com/en-us/dotnet/fsharp/language-reference/

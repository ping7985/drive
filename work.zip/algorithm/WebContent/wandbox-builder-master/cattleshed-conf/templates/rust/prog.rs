// This file is a "Hello, world!" in Rust language for wandbox.

fn main()
{
    println!("Hello, Wandbox!");
}

// Rust language references:
//   https://www.rust-lang.org/

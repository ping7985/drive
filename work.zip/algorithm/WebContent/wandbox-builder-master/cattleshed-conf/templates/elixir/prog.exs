# This file is a "Hello, world!" in Elixir language for wandbox.
defmodule Wandbox do
    def hello() do
        IO.puts "Hello, Wandbox!"
    end
end

Wandbox.hello()

# Elixir language references:
#   http://elixir-lang.org

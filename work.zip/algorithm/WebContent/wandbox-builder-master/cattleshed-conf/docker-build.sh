#!/bin/bash

docker build -t melpon/wandbox:cattleshed-conf .
